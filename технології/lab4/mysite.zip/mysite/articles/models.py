# articles/models.py
from django.db import models

class Article(models.Model):
    title = models.CharField(max_length=255)
    author = models.CharField(max_length=100)
    date_created = models.DateTimeField(auto_now_add=True)
    content = models.TextField()
    cover_image = models.ImageField(upload_to='article_covers/', null=True, blank=True)

    def __str__(self):
        return self.title
