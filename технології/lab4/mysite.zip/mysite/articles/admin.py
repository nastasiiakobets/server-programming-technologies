# articles/admin.py
from django.contrib import admin
from .models import Article

class ArticleAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'date_created', 'has_cover_image')

    def has_cover_image(self, obj):
        return obj.cover_image is not None

    has_cover_image.boolean = True
    has_cover_image.short_description = 'Has Cover Image'

admin.site.register(Article, ArticleAdmin)
