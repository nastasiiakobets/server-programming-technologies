from rest_framework import routers
from myapp.api.viewsets import ItemViewSet

router = routers.DefaultRouter()

router.register('items', ItemViewSet)