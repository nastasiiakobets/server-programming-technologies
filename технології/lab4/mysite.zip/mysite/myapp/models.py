from django.db import models
import datetime
from django.utils import timezone

class Item(models.Model):

    name = models.CharField('item name', max_length=100)

    price = models.FloatField('item_price')

    description = models.TextField('item description')

    date_created = models.DateTimeField('date created')

    is_active = models.BooleanField('is active item')

    image = models.ImageField(upload_to="gallery")

