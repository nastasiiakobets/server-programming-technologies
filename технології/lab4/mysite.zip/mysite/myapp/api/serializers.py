from ..models import Item

from rest_framework import serializers

class ItemSerializer(serializers.ModelSerializer):

    class Meta:

        model = Item

        fields = ('url', 'id', 'name', 'description', 'date_created', 'is_active', 'image' )

