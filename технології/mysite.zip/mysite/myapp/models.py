from django.db import models
import datetime
from django.utils import timezone
from django.contrib.auth.models import AbstractBaseUser
from .managers import UserAccountManager
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin
from django.core.exceptions import ValidationError


class Item(models.Model):

    name = models.CharField('item name', max_length=100)

    price = models.FloatField('item_price')

    description = models.TextField('item description')

    date_created = models.DateTimeField('date created')

    is_active = models.BooleanField('is active item')

    image = models.ImageField(upload_to="gallery")


class Account(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(verbose_name="email", unique=True)
    username = models.CharField(max_length=30, unique=True)
    date_joined = models.DateTimeField(verbose_name='date joined', auto_now_add=True)
    last_login = models.DateTimeField(verbose_name='last login', auto_now=True)
    is_admin = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)

    objects = UserAccountManager()

    groups = models.ManyToManyField(
        'auth.Group',
        related_name='account_groups',
        blank=True,
        verbose_name='groups',
        help_text='The groups this user belongs to.',
    )

    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='account_permissions',
        blank=True,
        verbose_name='user permissions',
        help_text='Specific permissions for this user.',
    )

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

    def clean(self):
        if self.email == "":
            raise ValidationError({"email": "This field cannot be blank."})

    def __str__(self):
        return self.email
