from django.shortcuts import render

# Create your views here.
from django.http import JsonResponse
from django.http import HttpResponse
from .models import Item
from .api.serializers import ItemSerializer


def index(request):

    data = Item.objects.order_by('-date_created')

    if request.method == 'GET':

        serializer = ItemSerializer(data, many=True)

        return JsonResponse(serializer.data, safe=False)
