from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import Account
from .forms import AccountCreationForm, AccountChangeForm


class CustomUserAdmin(UserAdmin):
    model = Account
    add_form = AccountCreationForm
    form = AccountChangeForm
    list_display = ['email', 'username']

admin.site.register(Account, CustomUserAdmin)
