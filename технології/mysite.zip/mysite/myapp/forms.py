from django import forms
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from .models import Account


class AccountCreationForm(UserCreationForm):
    class Meta:
        model = Account
        fields = ('email', 'username', 'password1', 'password2')


class AccountChangeForm(UserChangeForm):
    class Meta:
        model = Account
        fields = ('email', 'username')


class AccountForm(forms.ModelForm):
    class Meta:
        model = Account
        fields = ('email', 'username', 'is_active', 'is_admin', 'is_staff', 'is_superuser', 'groups', 'user_permissions')

    email = forms.EmailField()
